import dotenv from 'dotenv';

dotenv.config({ override: true });

// Pas besoin d'exporter dotenv, le fichier.env a bien été lu
// et chaque variable ajouté à process.env
