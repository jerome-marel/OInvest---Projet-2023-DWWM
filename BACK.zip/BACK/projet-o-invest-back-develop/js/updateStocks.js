import fetchAndUpdateStocks from './fetchStocks.js';

fetchAndUpdateStocks();
