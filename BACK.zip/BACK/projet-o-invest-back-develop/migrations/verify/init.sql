-- Verify o-invest:init on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
