const assetList = [
    { id: 1, name: 'Tesla', ticket: 'TSLA', value: '1516$' },
    { id: 2, name: 'Apple', ticket: 'AAPL', value: '1724$' },
    { id: 3, name: 'Amazon', ticket: 'AMZN', value: '1812$' },
    { id: 4, name: 'Microsoft', ticket: 'MSFT', value: '1250$' },
    { id: 5, name: 'Meta', ticket: 'META', value: '400$' },
    { id: 6, name: 'Netflix', ticket: 'NFLX', value: '824$' },
    { id: 7, name: 'Google', ticket: 'GOOGL', value: '967$' },
    { id: 8, name: 'Alibaba', ticket: 'BABA', value: '764$' },
    { id: 9, name: 'Uber', ticket: 'UBER', value: '213$' },
    { id: 10, name: 'Airbnb', ticket: 'ABNB', value: '1000$' },
    { id: 11, name: 'Intel', ticket: 'INTC', value: '1000$' },
    { id: 12, name: 'nvidia', ticket: 'NVDA', value: '587$' },
    { id: 13, name: 'AMD', ticket: 'AMD', value: '312$' },
    { id: 14, name: 'directX', ticket: 'DX', value: '421$' },
    { id: 15, name: 'disney', ticket: 'DIS', value: '367$' },
    { id: 16, name: 'Cocacola', ticket: 'KO', value: '320$' },
    { id: 17, name: 'Pepsi', ticket: 'PEP', value: '168$' },
    { id: 18, name: 'McDonalds', ticket: 'MCD', value: '987$' },
    { id: 19, name: 'Starbucks', ticket: 'SBUX', value: '20$' },
    { id: 20, name: 'Nike', ticket: 'NKE', value: '755$' },
    { id: 21, name: 'Zara', ticket: 'ZARA', value: '949$' },
   
  ];    
  
  export default assetList;